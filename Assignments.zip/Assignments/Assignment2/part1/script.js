"use strict";
/* eslint-disable */

window.onload = application;
function application() {
    // localStorage.setItem
    let div = document.querySelector("#output");
    let students = [{ id: 1, FirstName: "hamid", LastName: "said", Major: "MSD", Email: "test@miu.edu" },
    { id: 2, FirstName: "Amanuel", LastName: "Mecha", Major: "MSD", Email: "aman@miu.edu" }];

    // HomePage templete
    let homepage = `
    <h1>Well come to the student portal</h1>
  <button type="button" id="createnewstudent">Create New Student</button>
  <button  type="button" id="listallstudent">List All student</button>
  <button  type="button" id="deletestudent">Delete Student</button>
   `;

    // CreateStudent templete   
    let createStudent = ` 
    <form>
    ID: <input type="text" id="id">
     FirstName: <input type="text" id="fname">
    LastName: <input type="text" id="lname">
     Major: <input type="text" id="major">
     Email: <input type="text" id="email">
     <button type="button" id="submit">Save</button>
 </form>
    `;

    // DisplayAllStudent template
    let table = `
         <table border="collapse" id="table">
         <caption>Student LIst</caption>
                 <tr><th>ID</th><th>FirstName</th><th>LastName</th><th>Major</th><th>Email</th></tr>
       </table>
         `
    // Display DeletePage
    let DeletePage=`
    ID: <input type="text" id="deleteid">
    <button type="button" id="deletebutton">Delete</button>
    `
    // Appending the HomoPage templete and Adding event listener to the   createbutton,listbutton and deletebutton
    div.innerHTML = homepage;
    let createbutton = document.querySelector("#createnewstudent");
    let deletebutton = document.querySelector("#deletestudent");
    let listbutton = document.querySelector("#listallstudent");
    listbutton.addEventListener("click", listAllStudent);
    createbutton.addEventListener("click", displaycreateNewStudent);
    deletebutton.addEventListener("click", displayDeleteStudent);


    // append the createStudent templete and invoke the addEvent function
    function displaycreateNewStudent() {
        div.innerHTML = createStudent;
        addEvent();

    }


    //Add events into the after createStudent templete is appended

    function addEvent() {
        let submit = document.querySelector("#submit");
        submit.addEventListener("click", createstudent);
    }

    // create new student object and push it into the students array   
    function createstudent() {
        let id = document.querySelector("#id").value;
        let FirstName = document.querySelector("#fname").value;
        let LastName = document.querySelector("#lname").value;
        let Major = document.querySelector("#major").value;
        let Email = document.querySelector("#email").value;
        let obj = {
            id,
            FirstName,
            LastName,
            Major,
            Email
        }
        console.log(obj);
        students.push(obj);
        alert("successfully Added")
        div.innerHTML = homepage;

    }

    function listAllStudent() {
        div.innerHTML=table
        console.log("hello")
        for (let i = 0; i < students.length; i++) {
            let table = document.querySelector("#table");
            let row = document.createElement("tr");
            let td1 = document.createElement("td");
            let td2 = document.createElement("td");
            let td3 = document.createElement("td");
            let td4 = document.createElement("td");
            let td5 = document.createElement("td");
            td1.innerHTML = students[i].id;
            td2.innerHTML = students[i].FirstName;
            td3.innerHTML = students[i].LastName;
            td4.innerHTML = students[i].Major;
            td5.innerHTML = students[i].Email;
            row.append(td1);
            row.append(td2);
            row.append(td3);
            row.append(td4);
            row.append(td5);
            table.append(row);
        }
    }

    function displayDeleteStudent(){
        div.innerHTML=DeletePage;
        let deletebut=document.querySelector('#deletebutton');
        deletebut.addEventListener('click',deletefunc);
    }

    function deletefunc(){
        let id=parseInt(document.querySelector('#deleteid').value);
     let newarray;
     newarray=students.map(ele=>{
         if(ele.id!==id){
             return ele
         }
     })
     students=newarray;
     alert("successfully deleted")
     div.innerHTML=homepage;
    }


}

// console.log(students)