import React from 'react';

export default class ListStudent extends React.Component {
    render(){
        return (
           <div>
                <h1>List All Students</h1>
            <button type="button" >List Students</button>
           </div>
        )
    }
}