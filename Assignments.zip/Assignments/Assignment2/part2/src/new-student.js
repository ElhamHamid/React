import React from 'react';

export default function NewStudent(){
    return (
       <div>
            <h1> Create New Student </h1>
            <button type="button" >Create New Student</button>
            
       </div>
    )
}