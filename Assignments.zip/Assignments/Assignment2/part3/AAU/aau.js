"use strict";
/* eslint-disable */

const express=require('express');
const jwtManger = require('../JWT/jwtManger');
const router=express.Router();


class AAU {
    authenticate(req,res,next){
        if(req.url==='/api/v1/login' || req.url==='/api/v1/signup'){
            return next();
        }

        let token=req.headers.authorization;
        if(!token){
            res.json({status:"failed, please provide authorization"})
        }else{
            let data=jwtManger.verify(token);
            if(!data){
                res.json({status:"failed, authontication faild"})
            }
        }
        next();
    }

    isInputValid(req,res,next){
        if(req.metod==='POST'){
            if(req.body.fname===undefined || req.body.lname===undefined || req.body.email===undefined || req.body.password===undefined){
                  res.json({status:"failed, please fill the required fields"})  
                }else{
                    return next()
                }
        }
}
}


module.exports= new AAU()