"use strict";
/* eslint-disable */

const jwt=require('jsonwebtoken')
let secrete='Hamid-Secrete'

class JwtManger {
    generet(data){
        let token=jwt.sign(data,secrete);
        return token;
    }

    verify(token){
        let data=jwt.verify(token,secrete);
        return data;
    }
}


module.exports=new JwtManger()