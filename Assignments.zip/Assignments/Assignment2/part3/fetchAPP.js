"use strict";
/* eslint-disable */


window.onload = application;

function application() {

    let div = document.querySelector("#output");

    // HomePage templete
    let homepage = `
    <h1>Well come to the student portal</h1>
  <button type="button" id="createnewstudent">Create New Student</button>
  <button  type="button" id="listallstudent">List All student</button>
  <button  type="button" id="deletestudent">Delete Student</button>
   `;

    // CreateStudent templete   
    let createStudent = ` 
    <form>
    ID: <input type="text" id="id">
     FirstName: <input type="text" id="fname">
    LastName: <input type="text" id="lname">
     Major: <input type="text" id="major">
     Email: <input type="text" id="email">
     <button type="button" id="submit">Save</button>
 </form>
    `;

    // DisplayAllStudent template
    let table = `
         <table border="collapse" id="table">
         <caption>Student LIst</caption>
                 <tr><th>ID</th><th>FirstName</th><th>LastName</th><th>Major</th><th>Email</th></tr>
       </table>
         `
    // Display DeletePage
    let DeletePage=`
    ID: <input type="text" id="deleteid">
    <button type="button" id="deletebutton">Delete</button>
    `
    // Appending the HomoPage templete and Adding event listener to the   createbutton,listbutton and deletebutton
    div.innerHTML = homepage;
    let createbutton = document.querySelector("#createnewstudent");
    let deletebutton = document.querySelector("#deletestudent");
    let listbutton = document.querySelector("#listallstudent");
    listbutton.addEventListener("click", listAllStudent);
    createbutton.addEventListener("click", displaycreateNewStudent);
    deletebutton.addEventListener("click", displayDeleteStudent);


    // append the createStudent templete and invoke the addEvent function
    function displaycreateNewStudent() {
        div.innerHTML = createStudent;
        addEvent();

    }


    //Add events into the after createStudent templete is appended

    function addEvent() {
        let submit = document.querySelector("#submit");
        submit.addEventListener("click", createstudent);
    }

    // create new student object and push it into the students array   
    function createstudent() {
        let url='http://localhost:9000/api/v1/students'
        let id = document.querySelector("#id").value;
        let FirstName = document.querySelector("#fname").value;
        let LastName = document.querySelector("#lname").value;
        let Major = document.querySelector("#major").value;
        let Email = document.querySelector("#email").value;
        let obj = {
            FirstName,
            LastName,
            Major,
            Email
        }
        fetch(url,{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify(obj)
        }).then(data=>{
            let result=data.json()
            return result
            // console.log(data);
            // div.innerHTML = homepage;
        }).then(result=>{
           alert(result.status)
           div.innerHTML = homepage;
        }).catch(err=>{
            console.log(err)
        })
    }

    function listAllStudent() {
        let url='http://localhost:9000/api/v1/students'
        fetch(url,{
            method:'GET',
            headers:{'Content-Type':'application/json'}
        }).then(data=>{
            let result=data.json()
            return result
        }).then(result=>{
            console.log(result);
            let data=result.data
            div.innerHTML=table
            for (let i = 0; i < data.length; i++) {
                let table = document.querySelector("#table");
                let row = document.createElement("tr");
                let td1 = document.createElement("td");
                let td2 = document.createElement("td");
                let td3 = document.createElement("td");
                let td4 = document.createElement("td");
                let td5 = document.createElement("td");
                td1.innerHTML = data[i]._id;
                td2.innerHTML = data[i].fname;
                td3.innerHTML = data[i].lname;
                td4.innerHTML = data[i].email;
                td5.innerHTML = data[i].password;
                row.append(td1);
                row.append(td2);
                row.append(td3);
                row.append(td4);
                row.append(td5);
                table.append(row);
            }
        }).catch(err=>{
            console.log(err);
        })
    }

    function displayDeleteStudent(){
        div.innerHTML=DeletePage;
        let deletebut=document.querySelector('#deletebutton');
        deletebut.addEventListener('click',deletefunc);
    }

    function deletefunc(){
        let id=document.querySelector('#deleteid').value;
        let url=`http://localhost:9000/api/v1/students/${id}`
        fetch(url,{
            method:'DELETE'
            // headers:{'Content-Type':'application/json'}
        }).then(data=>{
            let result=data.json()
            return result
            
        }).then(result=>{
          alert(result.status)
            div.innerHTML=homepage;
        }).catch(err=>{
            console.log(err)
        })
    }


}