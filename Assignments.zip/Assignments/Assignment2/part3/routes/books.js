"use strict";
/* eslint-disable */

const express=require ('express');
const router=express.Router();
const { ObjectID } = require('bson');



router.get('/:id',function(req,res){
    req.db.collection('books').findOne({'id':req.params.id})
    .then(data=>{
        res.json({status:"success",result:data});
    }).catch(err=>{
        res.json({status:"faild" ,err:err});
    })
})


router.get('/',function(req,res){
    req.db.collection('books').find().toArray()
    .then(data=>{
        res.json({status:"success",result:data});
    }).catch(err=>{
        res.json({status:"faild" ,err:err});
    })
})

router.post('/',function(req,res){
    req.db.collection('books').findOne({id:req.body.id})
    .then(data=>{
        if(data){
            res.json({status:"failed,book already exist"});
        }else{
            req.db.collection('books').insertOne(req.body)
            .then(data=>{
                res.json({status:"success"})
            }).catch(err=>{
                res.json({status:"failed to insert data"})
            })
        }
    }).catch(err=>{
        res.json({status:"failed",err:err});
    })
})


router.put('/:id',function (req, res) {
    req.db.collection('books').findOne({id:req.params.id})
      .then((data) => {
        if (data) {
          req.db.collection('books').updateOne({ id:req.params.id}, { $set: { 'title':req.body.title, 'author': req.body.author } })
            .then(() => {
              res.json({ status: "success" });
            }).catch(() => {
              res.json({ status: "faild to update todo list" });
            })
        }
      }).catch((err) => {
        res.json({ status: "Faild", err: err });
      })
  });


router.delete('/:id',function(req,res){
    // console.log(req.params.id)
    req.db.collection('books').removeOne({_id:new ObjectID(req.params.id)})
    .then(data=>{
        res.json({status:"success"});
    }).catch(err=>{
        res.json({status:"faild" ,err:err});
    })
})


module.exports=router;