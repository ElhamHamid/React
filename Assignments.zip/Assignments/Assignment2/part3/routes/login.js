"use strict";
/* eslint-disable */

const express=require('express');
const jwtManger = require('../JWT/jwtManger');
const router=express.Router();


router.post('/',function(req,res,next){
    req.db.collection('students').findOne({email:req.body.email,password:req.body.password})
    .then(data=>{
        if(data){
            let obj={}
            obj.fname=data.fname;
            obj.email=data.email;
            let token=jwtManger.generet(obj);
            res.json({status:"success",result:token});
        }else{
            res.json({status:"faield, unkown user,please sign_up"})
        }
    }).catch(err=>{
        res.json({status:"failed",err:err});
    })
})



module.exports=router