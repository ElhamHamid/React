"use strict";
/* eslint-disable */

const express=require('express');
const router=express.Router();


router.post('/',function(req,res,next){
    req.db.collection('students').findOne({email:req.body.email,password:req.body.password})
    .then(data=>{
        if(data){
            res.json({status:"faield, User already exist"})
        }else{
            req.db.collection('students').insertOne(req.body)
            .then(data=>{
                res.json({status:"success"})
            }).catch(err=>{
                res.json({status:"faield",err:err});
            })
        }
    }).catch(err=>{
        res.json({status:"failed",err:err});
    })
})



module.exports=router