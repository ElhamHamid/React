"use strict";
/* eslint-disable */

const express=require ('express');
const router=express.Router();
const { ObjectID } = require('bson');

router.get('/',function(req,res){
    req.db.collection('students').find().toArray()
    .then(data=>{
        res.json({status:"success",data:data});
    }).catch(err=>{
        res.json({status:"faild" ,err:err});
    })
})


router.post('/',function(req,res){
    req.db.collection('students').findOne({email:req.body.email})
    .then(data=>{
        if(data){
            res.json({status:"failed,user already exist"});
        }else{
            req.db.collection('students').insertOne(req.body)
            .then(data=>{
                res.json({status:"success, data inserted"})
            }).catch(err=>{
                res.json({status:"failed to insert data"})
            })
        }
    }).catch(err=>{
        res.json({status:"failed",err:err});
    })
})


router.delete('/:id',function(req,res){
    req.db.collection('students').removeOne({_id:new ObjectID(req.params.id)})
    .then(data=>{
        res.json({status:"success, data deleted"});
    }).catch(err=>{
        res.json({status:"faild" ,err:err});
    })
})


module.exports=router;