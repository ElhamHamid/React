import logo from './logo.svg';
import './App.css';

import React from 'react'
import ListStudent from './list-students'
import NewStudent from './new-student'
import { useState } from 'react';


// Class Based Componenet
class App extends React.Component {
  state = {
    students: [
      { id: 1, FirstName: "hamid", LastName: "said", Major: "MSD", Email: "test@miu.edu" },
      { id: 2, FirstName: "Amanuel", LastName: "Mecha", Major: "MSD", Email: "aman@miu.edu" },
      { id: 3, FirstName: "Solomon", LastName: "Atsba", Major: "MSD", Email: "sol@miu.edu" },
      { id: 4, FirstName: "Tahir", LastName: "Kadir", Major: "MSD", Email: "tahir@miu.edu" },
    ]
  }
 //Delete the first element of the students array
  deleteFirstStudent=()=>{
    console.log("working....")

   let result=this.state.students.filter((item,index)=>{
     return index !==0
   })
this.setState({students:result});

  }
// will update the value of major properties of all the elements in the student array into 'MSD-2021' 
  changeMajor=()=>{
   let updated= this.state.students.map(item=>{
      return {
        id:item.id,
        FirstName:item.FirstName,
        LastName:item.LastName,
        Major:"MSD-2021",
        Email:item.Email
      }
    })
    this.setState({students:updated});
  }

  render() {
    return (
      <div className="App">
        {this.state.students.map(item=>{
          return (
            <ListStudent
            key={item.id}
            id={item.id}
            fName={item.FirstName}
            lName={item.LastName}
            Major={item.Major}
            Email={item.Email}
            />
          )
        })}
        <NewStudent />
        <button onClick={this.deleteFirstStudent}>Delete</button>
        <button onClick={this.changeMajor}>change Major</button>
      </div>
    );
  }
}


export default App;