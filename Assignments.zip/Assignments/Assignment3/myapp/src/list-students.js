import React from 'react';

export default function ListStudent (props) {
    return (
        <div>
             {/* <h1>List All Students</h1> */}
             <h2>{props.id}</h2>
             <h2>{props.fName}</h2>
             <h2>{props.lName}</h2>
             <h2>{props.Major}</h2>
             <h2>{props.Email}</h2>
        </div>
     )
}