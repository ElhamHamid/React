import React from 'react';

export default function NewStudent(){
    return (
       <div>
            <h1> Create New Student </h1>
            
       </div>
    )
}