import logo from './logo.svg';
import './App.css';
import Liststudents from './list-students'
import CreateNewStu from './new-student'
import React from 'react';

class App extends React.Component {
  constructor(props) {
    super(props)
    this.obj = {
      id:'',
      FirstName:'',
      LastName:'',
      Major:'',
      Email:''

    }
  }
  state = {
    students: [
      { id: 1, FirstName: "hamid", LastName: "said", Major: "MSD", Email: "test@miu.edu" },
      { id: 2, FirstName: "Amanuel", LastName: "Mecha", Major: "MSD", Email: "aman@miu.edu" },
      { id: 3, FirstName: "Solomon", LastName: "Atsba", Major: "MSD", Email: "sol@miu.edu" },
      { id: 4, FirstName: "Tahir", LastName: "Kadir", Major: "MSD", Email: "tahir@miu.edu" },
    ]
  }



  idEventHandeler = (event) => {
    this.obj.id = event.target.value;
  }

  fNameEventHandeler = (event) => {
    this.obj.FirstName = event.target.value;
  }
  lNameEventHandeler = (event) => {
    this.obj.LastName = event.target.value;
  }
  majorEventHandeler = (event) => {
    this.obj.Major = event.target.value;
  }
  emailEventHandeler = (event) => {
    this.obj.Email = event.target.value;
  }


  createNewStudent = () => {
    console.log(this.obj);
    let result =[...this.state.students];
    console.log(result)
    result.push(this.obj);
   this.setState({students:result});
  //  this.setState((currstatus)=>{
  //    return {students:currstatus.result}
  //  });
  }
  render() {
    return (
      <div>
        {this.state.students.map(item => {
          return <Liststudents
            key={item.id}
            FirstName={item.FirstName}
            LastName={item.LastName}
            Major={item.Major}
            Email={item.Email}
          />
        })}
        <CreateNewStu
          idEventHandeler={this.idEventHandeler}
          fNameEventHandeler={this.fNameEventHandeler}
          lNameEventHandeler={this.lNameEventHandeler}
          majorEventHandeler={this.majorEventHandeler}
          emailEventHandeler={this.emailEventHandeler}
          createNewStudent={this.createNewStudent}
        />
      </div>
    )
  }
}

export default App;
