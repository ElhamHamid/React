import React from 'react';

export default function Liststudents(props) {
     return (
          <div>
               <h2>{props.FirstName}</h2>
               <h2>{props.LastName}</h2>
               <h2>{props.Major}</h2>
               <h2>{props.Email}</h2>
          </div>
     )
}