import React from 'react';

export default function CreateNewStu(props) {
    return (
        <div>
            <p><input type='text' placeholder='your id' id='id' onChange={(event)=>{props.idEventHandeler(event)}} /></p>
            <p><input type='text' placeholder='your first name' fname='fname' onChange={(event)=>{props.fNameEventHandeler(event)}} /></p>
            <p><input type='text' placeholder='your last name' lname='lname' onChange={(event)=>{props.lNameEventHandeler(event)}} /></p>
            <p><input type='text' placeholder='your Major' major='major' onChange={(event)=>{props.majorEventHandeler(event)}} /></p>
            <p><input type='text' placeholder='your Email' email='email' onChange={(event)=>{props.emailEventHandeler(event)}} /></p>
            <button type='button' onClick={props.createNewStudent}>Add New Student</button>
        </div>
    )
}