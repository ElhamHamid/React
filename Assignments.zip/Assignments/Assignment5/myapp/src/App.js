import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react'
import Students from './students'
import AddStudent from './addNewStudent'
// class based component 
// class App extends React.Component {

// state={ students: [
//         { id: 1, FirstName: "hamid", LastName: "said", Major: "MSD", Email: "test@miu.edu" },
//         { id: 2, FirstName: "Amanuel", LastName: "Mecha", Major: "MSD", Email: "aman@miu.edu" },
//         { id: 3, FirstName: "Solomon", LastName: "Atsba", Major: "MSD", Email: "sol@miu.edu" },
//         { id: 4, FirstName: "Tahir", LastName: "Kadir", Major: "MSD", Email: "tahir@miu.edu" },
//       ]}


//   render(){
//     return (
//       <div>
//         <Students
//         students={this.state.students}
//         />
//       </div>
//     )
//   }
// }

// functional componenet 
function App() {
  const [currstu, updatestu] = useState({
    students: [
      { id: 1, FirstName: "hamid", LastName: "said", Major: "MSD", Email: "test@miu.edu" },
      { id: 2, FirstName: "Amanuel", LastName: "Mecha", Major: "MSD", Email: "aman@miu.edu" },
      { id: 3, FirstName: "Solomon", LastName: "Atsba", Major: "MSD", Email: "sol@miu.edu" },
      { id: 4, FirstName: "Tahir", LastName: "Kadir", Major: "MSD", Email: "tahir@miu.edu" },
    ]
  })

  const [newStudent, updateNewstudent] = useState({
    student: {
      id: '', FirstName: '', LastName: '', Major: '', Email: ''
    }
  })


  let deleteStudent = (id) => {
    let temp = [...currstu.students]
    let result = temp.filter(item => {
      return item.id !== id;
    })
    updatestu({ students: result })

  }
  const changeMajor = (event, id) => {
    let temp = [...currstu.students]
    let result = temp.map(item => {
      if (item.id === id) {
        return { id: item.id, FirstName: item.FirstName, LastName: item.LastName, Major: event.target.value, Email: item.Email }
      } else {
        return item;
      }
    })
    updatestu({ students: result })

  }

  let Idhundler = (event) => {
  //  console.log(event.target.value)
  let result={...newStudent.student}
  result.id=event.target.value
  updateNewstudent({student:result})
 
  }
  let Fnamehundler = (event) => {
    let result={...newStudent.student}
  result.FirstName=event.target.value
  updateNewstudent({student:result})
  }
  let Lnamehundler = (event) => {
    let result={...newStudent.student}
  result.LastName=event.target.value
  updateNewstudent({student:result})
  }
  let Majorhandler = (event) => {
    let result={...newStudent.student}
    result.Major=event.target.value
    updateNewstudent({student:result})
  }
  let Emailhundler = (event) => {
    let result={...newStudent.student}
    result.Email=event.target.value
    updateNewstudent({student:result})
  }

  let SubmitStudent = () => {
    console.log("working.....")
    let result=[...currstu.students]
    result.push(newStudent.student);
    updatestu({students:result})
  }

  return (
    <div>
      <Students
        students={currstu.students}
        deleteStudent={(id) => { deleteStudent(id) }}
        changeMajor={(event, id) => { changeMajor(event, id) }}
      />
      <AddStudent 
       Idhundler={(event)=>{Idhundler(event)}}
       Fnamehundler={(event)=>{Fnamehundler(event)}}
       Lnamehundler={(event)=>{Lnamehundler(event)}}
       Majorhandler={(event)=>{Majorhandler(event)}}
       Emailhundler={(event)=>{Emailhundler(event)}}
       SubmitStudent={SubmitStudent}
      />
         
    </div>
  )
}


export default App;
