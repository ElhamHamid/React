import React from 'react';

export default function AddStudent(props){
    return (
        <div>
            <h1>Add New Student</h1>
            <input type='text' placeholder="Id" onChange={props.Idhundler}/><br></br>
            <input type='text' placeholder="firstName" onChange={props.Fnamehundler}/><br></br>
            <input type='text' placeholder="lasttName" onChange={props.Lnamehundler}/><br></br>
            <input type='text' placeholder="Major" onChange={props.Majorhandler}/><br></br>
            <input type='text' placeholder="Email" onChange={props.Emailhundler}/><br></br>
            <button onClick={props.SubmitStudent}>Submit</button>
        </div>
    )
}