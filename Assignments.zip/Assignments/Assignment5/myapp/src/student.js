import React from 'react';


// export default class Student extends React.Component {
//     render() {
//         return (
//             <div>
//                 <h2>{this.props.FirstName}</h2>
//                 <h2>{this.props.LastName}</h2>
//                 <h2>{this.props.Major}</h2>
//                 <h2>{this.props.Email}</h2>
//             </div>
//         )
//     }
// }





// functional component
export default function Student(props) {
    return (
        <div>
            <h2>{props.FirstName}</h2>
            <h2>{props.LastName}</h2>
            <h2>{props.Major}</h2>
            <h2>{props.Email}</h2>
            <button onClick={props.deleteStudent}>Delete</button>
            <input type='text' value={props.Major} onChange={props.changeMajor}/>

        </div>
    )
}