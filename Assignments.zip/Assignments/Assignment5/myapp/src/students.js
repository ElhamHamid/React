import React from 'react';
import Student from './student'

//Optimize ‘students’ component by using ‘shouldComponentUpdate’  life-cycle hook
// export default class Students extends React.Component {

    // shouldComponentUpdate(currProps,nextstate){
    //     if(this.props.Students===currProps.Students){
    //         return false;
    //     }
    //     return true;
    // }

//     render(){
//         // console.log(" studentsrender")

//         return this.props.students.map(item=>{
//                     return <Student
//                     key={item.id}
//                     FirstName={item.FirstName}
//                     LasttName={item.LasttName}
//                     Major={item.Major}
//                     Email={item.Email}
                  
//                     />
//                 })
//     }
// }







export default function Students(props) {
    return props.students.map(item => {
        return <Student
            key={item.id}
            FirstName={item.FirstName}
            LasttName={item.LasttName}
            Major={item.Major}
            Email={item.Email}
            deleteStudent={()=>{props.deleteStudent(item.id)}}
            changeMajor={(event)=>{props.changeMajor(event,item.id)}}
        />
    }


    )

}


