import logo from './logo.svg';
import './App.css';
import axios from 'axios'
import React from 'react';
import Books from './books'
import AddNewBook from './createBook'
import Aux from './wrapper'

class App extends React.Component {

   state={
    books:[],
    book:{
      id:'',
      title:'',
      author:''
    },
  }

  // function that recieve id and update the book state
  idEventHundler=(event)=>{
    let book={...this.state.book}
    book.id=event.target.value;
    this.setState({book:book})
  }

  // function that recieve title and update the book state
  titleEventHundler=(event)=>{
    let book={...this.state.book}
    book.title=event.target.value;
    this.setState({book:book})
  }

  // function that recieve title and update the book state
  authorEventHundler=(event)=>{
    let book={...this.state.book}
    book.author=event.target.value;
    this.setState({book:book})
  }

  //function that add book the the database

  addBook=()=>{
    let body={...this.state.book}
    let url='http://localhost:9000/api/v1/books'
    axios.post(url,body)
    .then(response=>{
      if(response.data.status==='success'){
        this.fetchData();
        alert(response.data.status);
      }else{
        alert(response.data.status);
      }
    })
  }


  // function that retrive data from the back end
  fetchData=()=>{
    let url='http://localhost:9000/api/v1/books'
    axios.get(url)
    .then(response=>{
      if(response.data.status==='success'){
        this.setState({books:response.data.result})
      }else{
        alert(response.data.status);
      }
    }).catch(err=>{
      console.log(err);
    })
  }

// function that delete a book from the database
  deleteBook=(id)=>{
    let url=`http://localhost:9000/api/v1/books/${id}`
    axios.delete(url)
    .then(response=>{
      if(response.data.status==='success'){
        this.fetchData()
        alert(response.data.status)
      }
    }).catch(err=>{
      console.log(err)
    })
  }


// function that update title  of a book in the state
updaTetitleHundler=(event,id)=>{
  let books=[...this.state.books]
  let  result=books.map(item=>{
      if(item.id===id){
        return {
          id:item.id,
          title:event.target.value,
          author:item.author
        }
      }else{
        return item;
      }
    })
 
    this.setState({books:result})
}

//function that update Author  of a book in the state
updateAuthorHundler=(event,id)=>{
  let books=[...this.state.books]
  let  result=books.map(item=>{
      if(item.id===id){
        return {
          id:item.id,
          title:item.title,
          author:event.target.value
        }
      }else{
        return item;
      }
    })
 
    this.setState({books:result})

}
// function that update title and author of a book in the database
updateBook=(id)=>{
  let url=`http://localhost:9000/api/v1/books/${id}`
  let body;
  let books=[...this.state.books];
  let result=books.filter(item=>{
    return item.id===id;
  })
  body=result[0];
  axios.put(url,body)
  .then(response=>{
    if(response.data.status==='success'){
      this.fetchData()
      alert(response.data.status)
    }else{
      alert(response.data.status)
    }
  }).catch(err=>{
    console.log(err);
  })

}





  componentDidMount(){
    this.fetchData();
  }

  componentDidUpdate(){

  }

 render(){
   return (
    <Aux>
      <Books
      books={this.state.books}
      deleteBook={(id)=>{this.deleteBook(id)}}
      updaTetitleHundler={(event,id)=>{this.updaTetitleHundler(event,id)}}
      updateAuthorHundler={(event,id)=>{this.updateAuthorHundler(event,id)}}
      updateBook={(id)=>{this.updateBook(id)}}

      />
      <AddNewBook
      idEventHundler={(event)=>{this.idEventHundler(event)}}
      titleEventHundler={(event)=>{this.titleEventHundler(event)}}
      authorEventHundler={(event)=>{this.authorEventHundler(event)}}
      addBook={this.addBook}
      />
    </Aux>
   )
 }
}

export default App;
