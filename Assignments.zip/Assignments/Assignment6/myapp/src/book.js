import React from 'react'
import Aux from './wrapper'

export default class Book extends React.Component{
    render(){
        return (
            <div>
                <h2>{this.props.id}</h2>
                <h2>{this.props.title}</h2>
                <h2>{this.props.author}</h2>
                <input type='text' value={this.props.title} onChange={this.props.updaTetitleHundler} />
                <input type='text' value={this.props.author} onChange={this.props.updateAuthorHundler} /><br></br>
                <button type='button' onClick={this.props.updateBook}>Update</button>
                <button type='button' onClick={this.props.deleteBook}>Delete</button>
            </div>
        )
    }
}