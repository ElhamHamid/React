import React from 'react'
import Book from './book';
import Aux from './wrapper'

export default class Books extends React.Component{

    shouldComponentUpdate(nextProps,nextState){
        if(this.props.books !== nextProps.books){
            return true;
        }
        return false;
    }

    render(){
        return this.props.books.map((item)=>{
            return (
                <Aux>
                    <Book
                    key={item._id}
                    id={item.id}
                    title={item.title}
                    author={item.author}
                    deleteBook={()=>{this.props.deleteBook(item._id)}}
                    updaTetitleHundler={(event)=>{this.props.updaTetitleHundler(event,item.id)}}
                    updateAuthorHundler={(event)=>{this.props.updateAuthorHundler(event,item.id)}}
                    updateBook={()=>{this.props.updateBook(item.id)}}
                    />
                </Aux>
            )
        })
    }
}