import React from 'react';
import Aux from './wrapper'
export default class AddNewBook extends React.Component {

    render() {
        return (
            <div>
                <h1>Add New Book</h1>
                <input type='text' placeholder="Id, id must be unique" onChange={this.props.idEventHundler} /><br></br>
                <input type='text' placeholder="title" onChange={this.props.titleEventHundler} /><br></br>
                <input type='text' placeholder="author" onChange={this.props.authorEventHundler} /><br></br>
                <button type='button' onClick={this.props.addBook}>Add Book</button>
            </div>
        )
    }
}
