import React from 'react'

export default class Aux extends React.Component {
    render(){
        return this.props.children;
    }
}