import logo from './logo.svg';
import './App.css';
import React from 'react';
import Homepage from './homePage';
import { BrowserRouter, Route, Link } from "react-router-dom";

class App extends React.Component {
  render() {
    console.log("from App")
    return (
      <div>
        <BrowserRouter>
          <Homepage/>
        </BrowserRouter>
      </div>
    )
  }
}

export default App;
