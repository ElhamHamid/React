import axios from 'axios'
import React from 'react'


export default class Bookdetail extends React.Component {

state={
    book:undefined
}
componentDidMount(){
   console.log("componentDidMount")
    if(!this.state.book){
        let auth={headers:{Authorization:localStorage.getItem('token')}}
        let id=this.props.match.params.id
        console.log(id)
        let url= `http://localhost:9000/api/v1/books/${id}`
        axios.get(url,auth)
        .then(response=>{
            if(response.data.status==='success'){
                console.log(response.data.result)
                this.setState({book:response.data.result})
            }else{
                alert(response.data.status)
            }
        }).catch(err=>{
            console.log(err)
        })
    }
}
    render(){
        console.log("from bookdetail")
       let book=undefined
       if(this.state.book){
           book= <div>
               <h1>{this.state.book._id}</h1>
              <h1>{this.state.book.id}</h1>
              <h1>{this.state.book.title}</h1>
              <h1>{this.state.book.author}</h1>
           </div>
         
      
       }

       return(
          <div>
              {book}
          </div>
       )
    }
}