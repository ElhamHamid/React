import React from 'react'

export default class Hello extends React.Component{
    render(){
        return(
           <div>
               <h1>Hello World</h1>
           </div>
        )
    }
}