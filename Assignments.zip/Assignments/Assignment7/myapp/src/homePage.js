import React from 'react'
import { Route, Link, Switch } from "react-router-dom";
import Books from './books'
import Hello from './hello'
import Signup from './signup'
import Login from './login'
import Bookdetail from './bookDetails'


export default class Homepage extends React.Component {
    render() {
        console.log("from HomePage")
        return (
           <Switch>
               <Route exact path='/' component={MainPage}></Route>
               <Route exact path='/home' component={Home}></Route>
               <Route exact path='/books' component={Books}></Route>
               <Route exact path='/hello' component={Hello}></Route>
               <Route exact path='/signup' component={Signup}></Route>
               <Route exact path='/login' component={Login}></Route>
               <Route exact path='/:id' component={Bookdetail}></Route>
           </Switch>
        )
    }
}

const MainPage=()=>{
    return (
        <div>
                 <h1>Well Come To MIU Library</h1>
                <h2>Please login if you are already member or Signup, Thanks</h2><br></br>
               <ul>
                   <li> 
                       <Link to='/login'>Login</Link>
                   </li>
                   <li>
                       <Link to='/signup'>Signup</Link>
                   </li>
                  
               </ul>
        </div>
    )
}
const Home=()=>{
    return (
        <div>
                 <h1>Well Come Back To MIU Library</h1>
               <ul>
                   <li> 
                       <Link to='/books'>Books</Link>
                   </li>
                   <li>
                       <Link to='/hello'>Hello</Link>
                   </li>
                  
               </ul>
        </div>
    )
}
