import React from 'react'
import axios from 'axios'

export default class Login extends React.Component {
state={obj:{
    email:'',
    password:''
},

}

//function that takes email and update obj in the state 
// emailEventHandler=(event)=>{
//     console.log(event)
//     let obj={...this.state.obj}
//     obj.email=event.target.value
//     this.setState({obj:obj})
// }

//function that takes password and update obj in the state
// passwordEventHandler=(event)=>{
//     let obj={...this.state.obj}
//     obj.password=event.target.value
//     this.setState({obj:obj})
// }


//function that takes email/password from client and update obj in the state
EventHandler=(event)=>{
    let obj={...this.state.obj}
    obj[event.target.name]=event.target.value
    this.setState({obj:obj})
}

//function that submit obj from the state and update token in the state and also navigate to books component 
loginEventHandeler=()=>{
    let body=this.state.obj
    let url='http://localhost:9000/api/v1/login'
  axios.post(url,body)
  .then(response=>{
    if(response.data.status==='success'){
        console.log(response.data.result)
        localStorage.setItem('token',response.data.result)
        this.props.history.push('/home')
    }else{
        alert(response.data.status)
    }
  }).catch(err=>{
      console.log(err)
  })
}


    render() {
        // console.log("from Login")
        return (
            <div>
                <h1>Please login</h1>
                Email: <input type='text' name='email' onChange={this.EventHandler}/><br></br>
              Password: <input type='text' name='password' onChange={this.EventHandler}/><br></br>
                <button onClick={this.loginEventHandeler}>Login</button>
            </div>
        )
    }
}