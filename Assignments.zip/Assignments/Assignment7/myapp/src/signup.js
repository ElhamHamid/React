import axios from 'axios'
import React from 'react'

export default class Signup extends React.Component {
    state={obj:{
        fName:'',
        lName:'',
        email:'',
        major:'',
        password:''
    }
    
    }

//function that takes firstName and update obj in the state 
    // fNmaeEventHandler = (event) => {
    //     let obj = { ...this.state.obj }
    //     obj.fName = event.target.value
    //     this.setState({ obj: obj })
    // }

//function that takes lastName and update obj in the state  
    // lNmaeEventHandler = (event) => {
    //     let obj = { ...this.state.obj }
    //     obj.lName = event.target.value
    //     this.setState({ obj: obj })
    // }

//function that takes email and update obj in the state     
    // emailEventHandler = (event) => {
    //     let obj = { ...this.state.obj }
    //     obj.email = event.target.value
    //     this.setState({ obj: obj })
    // }

//function that takes major and update obj in the state     
    // majorEventHandler = (event) => {
    //     let obj = { ...this.state.obj }
    //     obj.major = event.target.value
    //     this.setState({ obj: obj })
    // }

//function that takes password and update obj in the state     
    // passwordEventHandler = (event) => {
    //     let obj = { ...this.state.obj }
    //     obj.password = event.target.value
    //     this.setState({ obj: obj })
    // }



//function that takes fNmae,lName,email,major and password from client and update obj in the state  
 EventHandler = (event) => {
        let obj = { ...this.state.obj }
        obj[event.target.name] = event.target.value
        this.setState({ obj: obj })
    }

//function that takes obj from the state and create new user on the backend      
    submitEventHundler=()=>{
      let body=this.state.obj;
      let url='http://localhost:9000/api/v1/signup'
      axios.post(url,body)
      .then(response=>{
          if(response.data.status==='success'){
              alert('user created, successfully')
              this.props.history.push('/login')
          }else{
              alert(response.data.status)
          }
      }).catch(err=>{
          console.log(err)
      })
    }   




    render() {
        return (
            <div>
                <h1>Please Sign Up</h1>
                firstNmae: <input type='text' name='fNmae' onChange={this.EventHandler}/><br></br>
              lastNmae: <input type='text' name='lNmae' onChange={this.EventHandler}/><br></br>
              email: <input type='text' name='email' onChange={this.EventHandler}/><br></br>
              major:  <input type='text'name='major'onChange={this.EventHandler}/><br></br>
              password: <input type='text' name='password'  onChange={this.passwordEventHandler}/><br></br>
                <button onClick={this.submitEventHundler}>Submit</button>

            </div>
        )
    }
}