
export const up='UPDATE'

export const delt='DELETE'


export const update=(payload)=>{
    return {
        type:'UPDATE',
        name:payload.name,
        value:payload.value,
        id:payload.id
    }
}
export const del=(val)=>{
    return {
        type:'DELETE',
        value:val
    }
}


