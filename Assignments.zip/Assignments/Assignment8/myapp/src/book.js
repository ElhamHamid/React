import React from 'react'

export default function Book (props){
    return (
        <div>
            <h2>{props.name}</h2>
            <h2>{props.author}</h2>
            <input type='text'name='name'value={props.name} onChange={props.update}/>
            <input type='text' name='author' value={props.author}onChange={props.update}/>
            {/* <button onClick={props.update}>Update</button> */}
            <button onClick={props.delete}>Delete</button>
        </div>
    )
}