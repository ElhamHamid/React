import React from 'react'
import Book from './book'
import { connect } from 'react-redux'
import * as actionType from './action'


class Books extends React.Component {

    eventHundler = (proper, value, id) => {
        this.props.update(proper, value, id)
    }

    del = (id) => {
        this.props.delete(id)
    }

    // componentDidUpdate(){
    //     this.eventHundler();
    //     this.del();
    // }


    render() {
        // console.log(this.props.books)
        return this.props.books.map(book => {
            return (
                <Book
                    key={book.id}
                    name={book.name}
                    author={book.author}
                    update={(event) => { this.eventHundler(event.target.name, event.target.value, book.id) }}
                    delete={() => { this.del(book.id) }}
                />
            )
        })
    }

}


const mapStateProp = (state) => {
    return {
        books: state.books
    }
}
const mapDispatchProp = (dispatch) => {
    return {
        update: (name, value, id) => { return dispatch(actionType.update({ name: name, value: value, id: id })) },
        delete: (id) => { return dispatch(actionType.del(id)) }
    }
}


export default connect(mapStateProp, mapDispatchProp)(Books)