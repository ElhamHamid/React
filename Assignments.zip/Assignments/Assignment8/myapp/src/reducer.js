import * as actionType from './action'


const initialState = {
    books: [
        { id: 1, name: 'intro to javaScript', author: 'Rakish' },
        { id: 2, name: 'intro to NodeJs', author: 'Umar' },
        { id: 3, name: 'intro to AP', author: 'Asaad' },
        { id: 4, name: 'intro to OOP', author: 'Levi' }
    ]
}



const reducer = (state = initialState, action) => {
    if (action.type === actionType.up) {
        console.log("update")
        let books = [...state.books]
        let result = books.map(book => {
            if (book.id === action.id) {
                let body = { ...book }
                body[action.name] = action.value
                return body
            } else {
                return book;
            }
        })
        return { books: result }
    }

    if (action.type === actionType.delt) {
        console.log("Delete")
        let books = [...state.books]
        let result = books.filter(book => {
            return book.id !== action.value
        });
        return { books: result }
    } else {
        console.log("state")
        return state;
    }


}

export default reducer