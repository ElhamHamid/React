import axios from 'axios'

export const fetch = 'FETCH_BOOKS'

export const update = 'UPDATE_BOOK'
export const updateOnstate='UPDATE_STATE_BOOK'

export const create = 'CREATE_BOOK'

export const delt = 'DELETE_BOOK'





// fetch Books action Creater
const FETCH = (res) => {
    return {
        type: fetch,
        value: res
    }
}

// delete Book action Creater
const DELETE = () => {
    return {
        type: delt,
    }
}

// update Book action Creater
 const UPDATE = () => {
    return {
        type: update
    }
}

// create Book action Creater
 const CREATE = () => {
    return {
        type: create
    }
}



export function fetchBooks() {
    return function (dispatch) {
        axios.get('http://localhost:9000/api/v1/books')
            .then(resp => {
                dispatch(FETCH(resp.data.result));
            }).catch(err => {
                console.log(err)
            })
    }
}

export function deleteBook(id) {
    return function (dispatch) {
        axios.delete(`http://localhost:9000/api/v1/books/${id}`)
            .then(resp => {
                if (resp.data.status === 'success') {
                    dispatch(DELETE())
                    dispatch(fetchBooks())
                }
            }).catch(err => {
                console.log(err)
            })
    }
}


export function updateBook(id,obj) {
    return function (dispatch) {
        axios.put(`http://localhost:9000/api/v1/books/${id}`, obj)
            .then(resp => {
                if (resp.data.status === 'success') {
                    dispatch(UPDATE())
                    dispatch(fetchBooks())
                }else{
                    alert(resp.data.status)
                }
            }).catch(err => {
                console.log(err)
            })
    }
}



export function CreateBook (obj){
    console.log(obj)
    return function (dispatch){
        axios.post('http://localhost:9000/api/v1/books',obj)
        .then(resp=>{
            if(resp.data.status==='success'){
                dispatch(CREATE());
                dispatch(fetchBooks())
            }else{
                alert(resp.data.status);
            }
        }).catch(err=>{
            console.log(err);
        })
    }
}


export function updateOnState(obj){
     return {
         type:updateOnstate,
         value:obj
     }
}