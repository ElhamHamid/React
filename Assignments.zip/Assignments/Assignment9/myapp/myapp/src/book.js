import React from 'react'

export default function Book (props){
    return (
        <div>
            <h2>{props.id}</h2>
            <h2>{props.title}</h2>
            <h2>{props.author}</h2>
            <input type='text'name='title'value={props.title} onChange={props.updatetHundler}/>
            <input type='text' name='author' value={props.author}onChange={props.updatetHundler}/>
            <button onClick={props.update}>Update</button>
            <button onClick={props.delete}>Delete</button>
        </div>
    )
}