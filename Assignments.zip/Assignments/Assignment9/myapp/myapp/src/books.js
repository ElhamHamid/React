import React from 'react'
import Book from './book'
import { connect } from 'react-redux'
import * as actionType from './action'
import axios from 'axios'


class Books extends React.Component {
    constructor(props) {
        super(props)
        this.obj = {id:undefined,title:'',author:''}
    }
    state={ updatedBook:{}}

    componentDidMount() {
        this.props.fetchBooks()
    }



// function that update an exsiting book  and hold it to an updatedBook
    updatetHundler = (proper, value, id) => {
        let payload={
            property:proper,
            value:value,
            id:id
        }
        // axios.get(`http://localhost:9000/api/v1/books/${id}`)
        // .then(res=>{
        //     if(res.data.status==='success'){
        //         this.setState({updateBook:res.data.result})
        //         // this.updatedBook=res.data.result;
        //         // console.log(this.updatedBook);
        //     }else{
        //         alert(res.data.status);
        //     }
        // }).catch(err=>{
        //     console.log(err)
        // })
        // let books = [...this.props.books]
        // let result = books.map(item => {
        //     return item.id === id
        // })
        // console.log(result)
        // this.updateBook=result
        // console.log(this.updateBook)
        // let obj={...this.updateBook}
        // obj[proper] = value;
        // this.updateBook = obj
        // console.log(this.updateBook)
    }
//function that sends id to the back end by dispatching action 
    del = (id) => {
        this.props.deleteBook(id)
    }

  
// function that create obj from the input event
    createhundler = (event) => {
        let temp = { ...this.obj };
        temp[event.target.name] = event.target.value;

        this.obj = temp;
    }

// function that sends obj to the back end by dispatching action    
createNewBook=()=>{
    this.props.createBook(this.obj);
    console.log(this.obj)
} 

    render() {

        return (
            <div>
                {
                    this.props.books.map(book => {
                        return (
                            
                            <Book
                                key={book._id}
                                id={book.id}
                                title={book.title}
                                author={book.author}
                                updatetHundler={(event) => { this.updatetHundler(event.target.name, event.target.value, book.id) }}
                                update={()=>{this.props.updateBook(book.id,this.props.updatedBook)}}
                                delete={() => { this.del(book._id) }}
                                createBook={()=>{this.props.createBook(this.obj)}}
                            />
                        )
                    })
                }
                <div>Add New Book</div>
                ID:<input type='number' name='id' onChange={(event)=>{this.createhundler(event)}} /><br></br>
        Title:<input type='text' name='title' onChange={(event)=>{this.createhundler(event)}} /><br></br>
        Author<input type='text' name='author' onChange={(event)=>{this.createhundler(event)}} /><br></br>
                <button onClick={this.createNewBook}>Create Book</button>

            </div>
        )

    }

}


const mapStateProp = (state) => {
    return {
        books: state.books,
        newBook: state.newBook,
        updatedBook:state.updatedBook
    }
}
const mapDispatchProp = (dispatch) => {
    return {
        fetchBooks: () => { dispatch(actionType.fetchBooks()) },
        deleteBook: (id) => { dispatch(actionType.deleteBook(id)) },
        updateBook: (id, obj) => { dispatch(actionType.updateBook(id, obj)) },
        createBook: (obj) => { dispatch(actionType.CreateBook(obj)) }

    }
}


export default connect(mapStateProp, mapDispatchProp)(Books)