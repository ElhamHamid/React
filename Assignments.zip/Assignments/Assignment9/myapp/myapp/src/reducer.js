import * as actionType from './action'


const initialState = {
    books: [],
    newBook:{id:undefined,title:'',author:''},
    updatedBook:{}
}



const reducer = (state = initialState, action) => {
    if (action.type === actionType.fetch) {
       return {...state,books:action.value}
    }

    if (action.type === actionType.delt) {
       return {...state}
    } 
    if (action.type === actionType.update) {
       return {...state}
    } 
    if (action.type === actionType.create) {
       return {...state}
    } 
    if (action.type === actionType.updateOnstate) {
       let books=[...state.books]
       let book=books.filter(item=>{
           return item.id===action.value.id;
       })
       state.updatedBook=book[0];
       let obj={...state.updatedBook}
       obj[action.value.property]=action.value.value

       return {updatedBook:obj}
    } 

return state;


}

export default reducer