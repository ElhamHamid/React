import * as actionType from './action'


const initialState = {
    books: [],
    newBook:{id:undefined,title:'',author:''},
    updatedBook:{},
    bookTobeUpdated:{}
}



const reducer = (state = initialState, action) => {
    if (action.type === actionType.fetch) {
       return {...state,books:action.value}
    }

    if (action.type === actionType.delt) {
       return {...state}
    } 
    if (action.type === actionType.update) {
       return {...state}
    } 
    if (action.type === actionType.create) {
       return {...state}
    } 
    if (action.type === actionType.bookTobeUpdated) {

       return {...state,bookTobeUpdated:action.value}
    } 
    if (action.type === actionType.updateOnstate) {
      let book={...state.bookTobeUpdated}
      book[action.value.property]=action.value.value;
      return {bookTobeUpdated:book}
   } 

return state;


}

export default reducer