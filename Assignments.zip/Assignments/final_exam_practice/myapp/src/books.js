import {Component} from 'react'


export default class Books extends Component{
    render(){
        return (
            <div>
                <h1>BooksPage</h1>
            </div>
        )
    }
}