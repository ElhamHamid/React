import {Component} from 'react'
import {Switch,Link,Route} from 'react-router-dom'
import Login from './login'
import Signup from './signup'
import Books from './books'


export default class Main extends Component{
    render(){
        return (
            <div>
                <Switch>
                    <Route exact path='/' component={SIGNINSIGNUP}/>
                    <Route exact path='/login' component={Login}/>
                    <Route exact path='/signup' component={Signup}/>
                    <Route exact path='/books' component={Books}/>
                    <Route exact path='/mainpage' component={MainPage}/>
                </Switch>
            </div>
        )
    }
}


const SIGNINSIGNUP=()=>{
    return (
        <div>
            <ul>
                <li>
                    <Link to='/login'>Login</Link>
                </li>
                <li>
                    <Link to='/signup'>SignUp</Link>
                </li>
            </ul>
        </div>
    )
}


const MainPage=()=>{
    return (
        <div>
            <ul>
                <li>
                    <Link to='/books'>Books</Link>
                </li>
              
            </ul>
        </div>
    )
}