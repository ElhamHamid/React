import {Component} from 'react'



export default class Signup extends Component{
    render(){
        return (
            <div>
                <h1>SignupPAge</h1>
            </div>
        )
    }
}