import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react'
import Hamid from './class_comp';
import Hello from './functional_comp';
import DefaultOutPut from './dynamicOutPut';
import Test from './functionProps';
import Siyam from './classProps';
import Hayat from './class_state'
import Anis from './iteratestatevalue'
import Students from './students'
import PrintMe from './HOC'


function App() {
  // JSX
return (
  <div>
    <h2>Hello there, this is from my first react app</h2>
    {/* <Hello/>
    <Hamid/>
    <DefaultOutPut/>
    <Test fname="Hamid" lname="Said">Hello Test</Test>
    <Siyam major="MSD" email="hamid@miu.edu"/>
    <Hayat/>
    <Anis/> */}
    <PrintMe/>
  </div>
)
}


// function App() {
//   const [studentsState, updateStudents] = useState({
//     students: [
//       { id: 1, FirstName: "Hamid", LastName: "Said", Major: "MSD", Email: "test@miu.edu" },
//       { id: 2, FirstName: "Amanuel", LastName: "Mecha", Major: "MSD", Email: "aman@miu.edu" },
//       { id: 3, FirstName: "Sol", LastName: "Atsba", Major: "MSD", Email: "Sol@miu.edu" },
//       { id: 4, FirstName: "Tahir", LastName: "Kedir", Major: "MSD", Email: "Tahir@miu.edu" }
//     ]
//   })

//   const [showStudentState, updateShowStudent] = useState({
//     ShowState: true
//   })

//   const showHideHandler = () => {

//     updateShowStudent({
//       ShowState: showStudentState.ShowState ? false : true
//     })
//   }

//   const updateFirstName = (event, id) => {
//     let result = [...studentsState.students];
//     let result2 = result.map(student => {
//       if (id === student.id) {
//         return {
//           id: student.id,
//           FirstName: event.target.value,
//           LastName: student.LastName,
//           Major: student.Major,
//           Email: student.Email
//         }
//       } else {
//         return student;
//       }
//     })
//     updateStudents({ students: result2 })

//   }

//   let students = ''
//   if (showStudentState.ShowState === true) {
//     students = <Students
//       students={studentsState.students}
//       updateFirstName={(event, id) => { updateFirstName(event, id) }}
//     />
//   }

//   return (
//     <div>
//       <button onClick={showHideHandler}>Show/Hide</button>
//       {students}
//     </div>
//   )

// }

export default App;
