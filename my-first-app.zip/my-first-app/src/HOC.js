import {Component} from 'react'


const D=(c)=>{
    return ({children})=>{
        return (
            <div>
                <span>Foo</span>
                <c>{children}</c>
            </div>
        )
    }
}


class Myclass extends Component {
    render(){
        const {children}=this.props
        return (
            <span>
                {children}
            </span>
        )
    }
}


const X=D(Myclass,"world")



export default function PrintMe(){
return(
    <div>
        <X>Helloo</X>
    </div>
)
}