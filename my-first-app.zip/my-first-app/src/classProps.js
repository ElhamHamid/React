import React from 'react';

export default class Siyam extends React.Component {
    render(){
        return (
            <div>
                <h1>{this.props.major}</h1>
                <h1>{this.props.email}</h1>
            </div>
        )
    }
}