import React from 'react';

export default class Hamid extends React.Component{
    render(){
        return (
            <div>
                <h1>Hello World, this is from class_based componenet</h1>
            </div>
        )
    }
}