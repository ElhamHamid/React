import React from 'react';

export default class Hayat extends React.Component{
    state={
        counter:1
    }
    increment=()=>{
        // this.setState({counter:this.state.counter +1})
       let {counter}=this.state
     counter+=1;
     this.setState({counter:counter})
    }
    render(){
        return (
            <div>
            <input type='label' value={this.state.counter}></input>
            <button onClick={this.increment}>Click Me</button>
          </div>
        )
    }
}