export default function DynamicOutPut(){
    return (
        <h3>this is the value:{Math.floor(Math.random() * 5) + 1}</h3>
    )
}