export default function Test(props){
    return (
        <div>
            <p>{props.fname}{props.lname}{props.children}</p>
        </div>
    )
}