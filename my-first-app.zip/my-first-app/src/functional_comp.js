import { Fragment } from "react";

export default function Hello(){
    return (
        <div>
             <h1>Hello World, this is from my first functional componenet</h1>
            
        </div>
    )
}