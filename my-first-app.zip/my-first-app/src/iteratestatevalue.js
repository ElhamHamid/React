import React from 'react';

export default class Anis extends React.Component {
    state = {
        students: [{ id: 1, FirstName: "hamid", LastName: "said", Major: "MSD", Email: "test@miu.edu" },
        { id: 2, FirstName: "Amanuel", LastName: "Mecha", Major: "MSD", Email: "aman@miu.edu" }]
    }

    delete=(id)=>{
       let result=this.state.students.filter(student=>{
        return id !== student.id
       });
       this.setState({students:result})
    }


render(){
    return (
        <div>
            {
                this.state.students.map(student=>{
                    return (
                 <div key={student.id}>
                     <h2>{student.id}</h2>
                     <h2>{student.FirstName}</h2>
                     <h2>{student.LastName}</h2>
                     <h2>{student.Major}</h2>
                     <h2>{student.Email}</h2>
                     <button onClick={()=>{this.delete(student.id)}}>Delete</button>
                 </div>
                    )
                })
            }
        </div>
    )
}


}