export default function Student (props){
    return(
        <div>
            <h1>{props.FirstName}</h1>
            <h1>{props.LastName}</h1>
            <h1>{props.Major}</h1>
            <h1>{props.Email}</h1>
            <input type='text' value={props.FirstName} onChange={props.updateFirstName}/>
        </div>
    )

}