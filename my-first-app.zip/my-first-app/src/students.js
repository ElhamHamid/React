import Student from './student'


export default function Students(props) {
    return (
        props.students.map(item => {
            return <Student
                key={item.id}
                FirstName={item.FirstName}
                LastName={item.LastName}
                Major={item.Major}
                Email={item.Email}
                updateFirstName={(event)=>{props.updateFirstName(event,item.id)}}
            />
        })
    )
}